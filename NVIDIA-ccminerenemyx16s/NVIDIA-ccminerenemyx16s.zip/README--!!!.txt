ccminer/enemy-1.04a (z-enemy)  From: Dk & Enemy
-Fix rare bug - stuck  after switch pool
-Add x16s support
-Fix 11+ card support
______________________________________
RECOMMENDED SETTING:
First start:
1) for better stability and speed, update your drivers on http://www.nvidia.com/Download/index.aspx
ver, 390++++
2) PL 70-80% ( depend on PSU )
3) Core :( some + or stock )
4) Mem : ( Zero , can be  +++)
5) Intensity default : ( -i 19 or 20 for 1080ti  )
6) Yiimp pools rec manual diff, like : ( -p d=16 ) - for  small farms or  (-p d=48 )- for good farms like 6-8 1080ti

OverClock slowly, after stable work ( core,mem and PL) . High intensity not recommended !!! 

P.S. Please upload only my links or links confirmed by me, for security reasons !!!